Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/upload-and-store-video-to-mysql-database-with-php/

Instructions -

1. Import attached videos.sql in your database.
2. Update config.php file
3. Run index.php file to upload video files.
4. Run readvideos.php file to view uploaded video files.